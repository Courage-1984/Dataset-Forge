#!/usr/bin/env ruby

puts "Starting zsteg_cli.rb..."
puts "ARGV: #{ARGV.inspect}" # Inspect the arguments received

STDOUT.flush
STDERR.flush

# Handle zlib dependency issue for OCRA builds
begin
  # Try to load zlib with explicit path handling
  if ENV['OCRA_EXECUTABLE']
    # We're running from an OCRA executable
    puts "Running from OCRA executable, handling native dependencies..."
    
    # Add the current directory to the DLL search path
    require 'fiddle'
    require 'fiddle/import'
    
    # Try to load zlib1.dll from the same directory as the executable
    begin
      Fiddle.dlopen('zlib1.dll')
      puts "Successfully loaded zlib1.dll"
    rescue LoadError => e
      puts "Warning: Could not load zlib1.dll: #{e.message}"
      puts "This may cause issues with zsteg functionality"
    end
  end
  
  require 'zsteg'
  require 'zsteg/cli/cli'
  
  # Simple wrapper that passes through all arguments
  ZSteg::CLI::Cli.new.run
  
rescue LoadError => e
  if e.message.include?('zlib')
    puts "Error: zlib library not found or incompatible"
    puts "This is a known issue with OCRA-built executables on Windows"
    puts ""
    puts "Solutions:"
    puts "1. Install zsteg using gem: gem install zsteg"
    puts "2. Use the original Ruby installation instead of the OCRA executable"
    puts "3. Rebuild the OCRA executable with proper native dependencies"
    puts ""
    puts "For immediate use, try: gem install zsteg && zsteg --help"
    exit 1
  else
    puts "Error loading zsteg: #{e.message}"
    puts "Please ensure zsteg is properly installed: gem install zsteg"
    exit 1
  end
rescue => e
  puts "Unexpected error: #{e.message}"
  puts e.backtrace.join("\n")
  exit 1
end

puts "End of script reached."
STDOUT.flush
STDERR.flush

